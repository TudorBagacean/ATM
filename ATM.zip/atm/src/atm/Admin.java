package atm;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import java.io.*;


public class Admin extends JFrame implements ActionListener
{
    
    
     
    JButton addAccount,deleteAccount,editAccount,saveToFile,logOut;  
    JLabel atmLab;
    Container con;
    ArrayList customerlist;
    String s1,s2,s3;
    Admin()
    {
        super("ADMIN");
        customerlist=new ArrayList();       
		
        con = this.getContentPane();
        con.setLayout(null);
        con.setBackground(Color.lightGray);
       
        atmLab = new JLabel(new ImageIcon("admin2.png"));
        atmLab.setBounds(10,10,500,100);
        
        addAccount = new JButton("Adauga Cont");
        addAccount.setBounds(20,120,150,30);
               
        deleteAccount = new JButton("Stergere Cont");
        deleteAccount.setBounds(350,120,150,30);
        
        editAccount = new JButton("Editare Cont");
        editAccount.setBounds(20,200,150,30);
        
        saveToFile = new JButton("Salveaza in fisier");
        saveToFile.setBounds(350,200,150,30);
        
        logOut = new JButton("IESIRE");
        logOut.setBounds(190,250,150,30);

       
       con.add(atmLab);
       con.add(addAccount);
       con.add(deleteAccount);
       con.add(editAccount);
       con.add(saveToFile);
       con.add(logOut);
       
    /****************************     Butoane cu ActionListener    ******************************/
    
    addAccount.addActionListener(this);
    deleteAccount.addActionListener(this);
    editAccount.addActionListener(this);
    saveToFile.addActionListener(this);
    logOut.addActionListener(this);
    
    
    }
    
    /*******************************Adaugare cont************************************************/
    public void addPersons()
	{
		String pincode=JOptionPane.showInputDialog(null,"Te rog introdu un cod PIN","INTRODUCERE PIN",JOptionPane.QUESTION_MESSAGE);
		for(int i=0;i<customerlist.size();i++)
		{
			AccountData atm=(AccountData)customerlist.get(i);
			if(pincode.equals(atm.pincode))
			{
				pincode=JOptionPane.showInputDialog(null,"!Acest cod PIN este deja folosit de catre alt client \nIntrodu alt cod PIC","INTRODUCERE PIN",JOptionPane.QUESTION_MESSAGE);	
			}
		}
		String customername=JOptionPane.showInputDialog(null,"Introdu numele clientului","NUME CLIENT",JOptionPane.QUESTION_MESSAGE);
		String accounttype=JOptionPane.showInputDialog(null,"Intordu tipul contului(depozit sau curent)","TIPUL DE CONT AL CLIENTULUI",JOptionPane.QUESTION_MESSAGE);
		String accountnumber=JOptionPane.showInputDialog(null,"Introdu numarul contului","NUMARUL DE CONT AL CLIENTULUI",JOptionPane.QUESTION_MESSAGE);
		String startbalance=JOptionPane.showInputDialog(null,"Introdu soldul intial","SOLDUL INITIAL AL CLIENTULUI",JOptionPane.QUESTION_MESSAGE);

		AccountData atm=new AccountData(pincode,customername,accounttype,accountnumber,startbalance);
		customerlist.add(atm);
	}
    
    /**************************************Salvare conturi*********************************************************/
    
    public void savePerson()
	{
		try
		{
			AccountData atm;
			String line,line1;

			FileWriter fr=new FileWriter("Customer Record.txt");
			PrintWriter pw=new PrintWriter(fr);

			FileWriter fr1=new FileWriter("Customers Record.txt");
			PrintWriter pw1=new PrintWriter(fr1);

			pw1.print("PINCODE\t\t\tCUSTOMER NAME\t\t      ACCOUNT TYPE\t\tACCOUNT NUMBER\t\tSTARTING BALANCE\n");	
			for (int i=0;i<customerlist.size(); i++)
			{
				atm=(AccountData)customerlist.get(i);
				line=atm.pincode+","+atm.customername+","+atm.accounttype+","+atm.accountnumber+","+atm.startbalance+"\n";		
				line1=atm.pincode+"\t\t\t"+atm.customername+"\t\t\t"+atm.accounttype+"\t\t\t"+atm.accountnumber+"\t\t\t"+atm.startbalance;
				pw1.println(line1);
				pw.print(line);
			}
			pw.flush();
			pw1.flush();
			pw.close();
			pw1.close();
			fr.close();
			fr1.close();
		}
		catch(IOException ioEX)
		{
			System.out.println(ioEX);
		}
		
	}
/********************************************Stergere cont*******************************************************/
    
    public void delete(String n)
	{
		int aa;
		
		for(int i=0;i<customerlist.size();i++)
		{
			AccountData atm=(AccountData)customerlist.get(i);
			if(n.equals(atm.pincode))
			{
				aa=JOptionPane.showConfirmDialog(null,"Do you really want to delete The Following Record"+"\n\nPINCODE : "+atm.pincode+"\nCustomer name : "+atm.customername+"\nAccount Type : "+atm.accounttype+
				"\nAccount Number : "+atm.accountnumber+"\nTotal Balance : "+atm.startbalance,"CONFIRMATION ABOUT DELETION",JOptionPane.YES_NO_OPTION);
				if(aa==JOptionPane.YES_OPTION)
				{
					customerlist.remove(i);
				}
				else
				{
					break;
				}	
			}
			
		}
		
	}
    
    /****************************************Editare cont****************************************************/
   

	public void edit(String n)
	{
		String aa;
		int ch;
		for(int i=0;i<customerlist.size();i++)
		{
	int bb;
	AccountData atm=(AccountData)customerlist.get(i);
	if(n.equals(atm.pincode))
            {
	bb=JOptionPane.showConfirmDialog(null,"Vrei sa editezi aceasta inregistrare?"+"\n\nPINCODE : "+atm.pincode+"\nNume Client : "+atm.customername+"\nTip Cont : "+atm.accounttype+
	"\nAccount Number : "+atm.accountnumber+"\nTotal Balanta : "+atm.startbalance,"CONFIRMATION BOX",JOptionPane.YES_NO_OPTION);
	if(bb==JOptionPane.YES_OPTION)
            {
	aa=JOptionPane.showInputDialog(null,"Apasa 1 - Editare Cod PIN\nApasa 2 - Editare Nume Client \nApasa 3 - Editare Tip Cont\nApasa 4 - Editare Numar Cont\nApasa 5 - Editare Suma Intiala\n\n ","MENIU EDITARE",JOptionPane.INFORMATION_MESSAGE);
	ch=Integer.parseInt(aa);										
	switch(ch)
	{
	case 1:
	atm.pincode=JOptionPane.showInputDialog(null,"Introdu noul cod PIN ","EDITARE COD PIN",JOptionPane.QUESTION_MESSAGE);
	savePerson();
	break;

	case 2:
	atm.customername=JOptionPane.showInputDialog(null,"Introdu noul nume al clientului ","EDITARE NUME CLIENT",JOptionPane.QUESTION_MESSAGE);
	savePerson();
	break;
	
	case 3:
	atm.accounttype=JOptionPane.showInputDialog(null,"Introdu Tip Cont\n(Saving or Current)","EDITARE TIP CONT",JOptionPane.QUESTION_MESSAGE);
	savePerson();
	break;

	case 4:
	atm.accountnumber=JOptionPane.showInputDialog(null,"Introdu numarul contului","NUMAR CONT",JOptionPane.QUESTION_MESSAGE);
	savePerson();
	break;
        
	case 5:
	atm.startbalance=JOptionPane.showInputDialog(null,"Introdu noul sold ","EDITARE SOLD INITIAL",JOptionPane.QUESTION_MESSAGE);
	savePerson();
	break;
        
	default:
	JOptionPane.showMessageDialog(null,"! AI INTRODUS UN COD PIN GRESIT! \nTe rog introdu un cod PIN valid","MULTUMESC",JOptionPane.WARNING_MESSAGE);
		}
			
		}
        else
	{
		break;
	}
	}
				
		}
	}

    /************************************************************************************************************/
    
    /***************************************************************************************************/
    public void actionPerformed(ActionEvent e)
    {

    
        JButton b = (JButton)e.getSource();
        
        
        if(b==addAccount)
        {
            
            addPersons();
        }
        if(b==deleteAccount)
        {
            s1=JOptionPane.showInputDialog(null,"Introdu codul PIN pentru stergerea contului","DELETION MENU",JOptionPane.QUESTION_MESSAGE);
            delete(s1);
        }
        if(b==editAccount)
        {
            s1=JOptionPane.showInputDialog(null,"Introdu codul PIN pentru editarea contului","EDITING MENU",JOptionPane.QUESTION_MESSAGE);
            edit(s1);
        }
        if(b==saveToFile)
        {
            savePerson();
        }       	
        
        if(b == logOut)
        {					
	int n=JOptionPane.showConfirmDialog(null,"Esti sigur ca vrei sa iesi?","Iesire",JOptionPane.YES_NO_OPTION);
		if(n==JOptionPane.YES_OPTION)
                {
		JOptionPane.showMessageDialog(null,"La revedere!","ATM",JOptionPane.INFORMATION_MESSAGE);
		System.exit(0);
		dispose();
                }

        }
    
    }  
   
}
