package atm;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import java.io.*;
 
public class AfterLogin extends JFrame implements ActionListener
{
    
    JButton equiryBtn,withdrawBtn,logoutBtn,transferBtn;  
    JLabel atmLab;
    Container con;
    ArrayList customerlist;
    Admin adm = new Admin();
    String s1;
    
    AfterLogin()
    {
        
        super("Tranzactii");
        customerlist=new ArrayList();
        
        con = this.getContentPane();
        con.setLayout(null);
        con.setBackground(Color.lightGray.brighter());
       
        
        atmLab = new JLabel(new ImageIcon("atm.png"));
        atmLab.setBounds(60,10,300,100);
        
        equiryBtn = new JButton("Interogare Sold");
        equiryBtn.setBounds(10,130,150,40);
        
        transferBtn = new JButton("Transfera Bani");
        transferBtn.setBounds(260,130,150,40);
        
        withdrawBtn = new JButton("Retragere Bani");
        withdrawBtn.setBounds(260,230,150,40);
        
     
        logoutBtn = new JButton("Iesire");
        logoutBtn.setBounds(10,230,150,40);
               
       con.add(atmLab);
       con.add(equiryBtn);
       con.add(withdrawBtn);
       con.add(transferBtn);
       con.add(logoutBtn);
    /********************************************************************/
    
    equiryBtn.addActionListener(this);
    transferBtn.addActionListener(this);
    withdrawBtn.addActionListener(this);
    logoutBtn.addActionListener(this);
   
    loadPersons();
    }
    /*****************************Incarcare date din fisier****************************************/ 
   
    	public void loadPersons()
	{
		String ss[]=null;
		String pincode,customername,accounttype,accountnumber,startbalance;
		
		try
		{
			FileReader fr=new FileReader("Customer Record.txt");
			BufferedReader br=new BufferedReader(fr);
			

			String line=br.readLine();	
			
			while(line != null)
			{
				ss=line.split(",");
				pincode=ss[0];
				customername=ss[1];
				accounttype=ss[2];
				accountnumber=ss[3];
				startbalance=ss[4];

				AccountData atm=new AccountData(pincode,customername,accounttype,accountnumber,startbalance);
				customerlist.add(atm);
				line=br.readLine();
			}
				br.close();
				fr.close();
		}
		catch(IOException ioEX)
		{
			System.out.println(ioEX);
		}
	}

/***************************************************************************************************************************/


/********************************************************* Interogare sold client ************************************/        
	public void inquiry(String n)
	{
		for(int i=0;i<customerlist.size();i++)
		{
			AccountData atm=(AccountData)customerlist.get(i);
			if(n.equals(atm.pincode))
			{
				JOptionPane.showMessageDialog(null,"Bine ai venit ."+atm.customername+"\nSoldul contului este : "+atm.startbalance,"BUN VENIT  "+atm.customername,JOptionPane.INFORMATION_MESSAGE);
			}
		}
	}
/***************************************************************************************************************************/


/****************************************************** Transfer sold ***************************************************/
	public void transfer(String k)
	{
		String a,b,c;
		int d,e,f;


		for(int i=0;i<customerlist.size();i++)
		{
			AccountData atm=(AccountData)customerlist.get(i);
			if(k.equals(atm.pincode));
			{
				a=atm.startbalance;
				d=Integer.parseInt(a);

				c=JOptionPane.showInputDialog(null,"Introdu contul catre care transferi suma","MENIU TRANZACTII",JOptionPane.QUESTION_MESSAGE);
				b=JOptionPane.showInputDialog(null,"Introdu suma de transferat","MENIU TRANZACTII",JOptionPane.QUESTION_MESSAGE);
				e=Integer.parseInt(b);

				f=d-e;
				while(f < 0)
				{
					a=atm.startbalance;
					d=Integer.parseInt(a);

					b=JOptionPane.showInputDialog(null,"Fonduri insuficiente\nIntrodu suma corecta pt transfer","MENIU TRANZACTII",JOptionPane.WARNING_MESSAGE);
					e=Integer.parseInt(b);
					f=d-e;
				}
				String u=String.valueOf(f);
				atm.startbalance=u;
				
				JOptionPane.showMessageDialog(null,"Tranzactia s-a efectuat cu succes\n\nSuma de "+b+"este transferata "+c+"\n\nSoldul tau total : "+atm.startbalance,"TRANZACTIE PROCESATA",JOptionPane.INFORMATION_MESSAGE);
				
                                Admin as = new Admin();
				as.savePerson();
			}	
		}
	}

/**********************************************************************************************************************************/


/********************************************************* Retragere numerar ******************************************************/        
	public void withdraw(String o)
	{
		String a,b,c;
		int d,e,f;

		for(int i=0;i<customerlist.size();i++)
		{
			AccountData atm=(AccountData)customerlist.get(i);
			if(o.equals(atm.pincode))
			{
				a=atm.startbalance;
				d=Integer.parseInt(a);

				b=JOptionPane.showInputDialog(null,"Introdu suma de retras:","MENIU RETRAGERE",JOptionPane.QUESTION_MESSAGE);
				e=Integer.parseInt(b);

				f=d-e;

				while(f <0)
				{
					a=atm.startbalance;
					d=Integer.parseInt(a);

					b=JOptionPane.showInputDialog(null,"Suma incorecta\nIntrodu o suma suficienta care poate fi retrasa","MENIU RETRAGERE",JOptionPane.WARNING_MESSAGE);
					e=Integer.parseInt(b);

					f=d-e;
				}
				c=String.valueOf(f);
				atm.startbalance=c;
				JOptionPane.showMessageDialog(null,"Retragere procesata\nAi retras suma de "+b+"\nSoldul tau este acum: "+atm.startbalance,"Informatii",JOptionPane.INFORMATION_MESSAGE);
				Admin ad = new Admin();
                                ad.savePerson();
			}
		}
	}
/********************************************************************************************************************************/



/*************************************** ActionListener Cod pentru butoane ***********************************************************/
    
    public void actionPerformed(ActionEvent e)
    {
        JButton b = (JButton)e.getSource();
        
	if(b == equiryBtn)
        {		
            s1= JOptionPane.showInputDialog(null,"Introdu codul PIN pt verificarea soldului ","Verifica sold",JOptionPane.QUESTION_MESSAGE);
            
            
            		for(int i=0;i<customerlist.size();i++)
		{
			AccountData atm=(AccountData)customerlist.get(i);

			if(!s1.equals(atm.pincode))
			{
				JOptionPane.showMessageDialog(null,"Ai introdus con PIN gresit \nIntrodu codul PIN valid!!!!","Atentie",JOptionPane.WARNING_MESSAGE);
					
			}
                        else if(s1.equals(atm.pincode))
			{
			
                            inquiry(s1);
                        }            
                }
        }
/******************************************************************************************************************************/
        
        if(b == withdrawBtn)
        {
          s1=JOptionPane.showInputDialog(null,"Introdu cod PIN pentru retragere numerar ","MENIU RETRAGERE",JOptionPane.QUESTION_MESSAGE);
           for(int i=0;i<customerlist.size();i++)
		{
			AccountData atm=(AccountData)customerlist.get(i);

                         if(s1.equals(atm.pincode))
			{
			
                            withdraw(s1);
                        }
                         
                         else if(!s1.equals(atm.pincode))
			{
				JOptionPane.showMessageDialog(null,"Ai introdus con PIN gresit \nIntrodu codul PIN valid!!!!","Atentie",JOptionPane.WARNING_MESSAGE);
					
			}
                }
        }
/******************************************************************************************************************************/

        if(b == transferBtn)
        {
             s1=JOptionPane.showInputDialog(null,"Introdu cod pin pentru a transfera ","Sold",JOptionPane.QUESTION_MESSAGE);
           	
             for(int i=0;i<customerlist.size();i++)
		{
			AccountData atm=(AccountData)customerlist.get(i);

			if(!s1.equals(atm.pincode))
			{
				JOptionPane.showMessageDialog(null,"Ai introdus con PIN gresit \nIntrodu codul PIN valid!!!!","Atentie",JOptionPane.WARNING_MESSAGE);
					
			}
                        else if(s1.equals(atm.pincode))
			{
			
                            transfer(s1);
                        }            
                }        
        }
        
/******************************************************************************************************************************/
        
            if(b == logoutBtn)
        {					
	int n=JOptionPane.showConfirmDialog(null,"Esti sigur ca vrei sa iesi?","Iesire",JOptionPane.YES_NO_OPTION);
		if(n==JOptionPane.YES_OPTION)
                {
		JOptionPane.showMessageDialog(null,"La revedere!","ATM",JOptionPane.INFORMATION_MESSAGE);
		System.exit(0);
                }

        }
            
   /******************************************************************************************************************************/                             
    
    
    
    
    }  
   
}
